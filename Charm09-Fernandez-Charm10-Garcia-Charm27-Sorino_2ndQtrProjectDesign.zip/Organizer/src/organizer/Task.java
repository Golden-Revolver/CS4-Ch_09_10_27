package organizer;
import java.util.*;
/**
 *
 * @author Christian Brandon
 */
public class Task {
    protected String name;
    protected String id;
    protected boolean complete;
    
    public Task(String name) {
        this.name = name;
        id = UUID.randomUUID().toString();
        complete = false;
    }
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public boolean isComplete() {
        return complete;
    }
    public void setComplete(boolean complete) {
        this.complete = complete;
    }
}