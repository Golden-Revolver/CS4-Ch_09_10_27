package organizer;
/**
 *
 * @author Christian Brandon
 */
public class Habit extends Task {
    private int streak;
    
    public Habit(String name) {
        super(name);
        streak = 0;
    }
    
    public int getStreak() {
        return streak;
    }
    public void setStreak(int streak) {
        this.streak = streak;
    }
    public void updateStreak() {
        if (complete) streak++;
        else streak = 0;
    }
}