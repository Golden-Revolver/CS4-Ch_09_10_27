package organizer;
import java.time.*;
/**
 *
 * @author Christian Brandon
 */
public class Goal extends Task {
    private LocalDateTime deadline;
    private double progress, target;
    private boolean reward;
    
    public Goal(String name, double target, LocalDateTime deadline) {
        super(name);
        this.target = target;
        progress = 0;
        reward = true;
        this.deadline = deadline;
    }
    public Goal(String name, double target, 
            boolean reward, LocalDateTime deadline) {
        super(name);
        this.target = target;
        progress = 0;
        this.reward = reward;
        this.deadline = deadline;
    }
    public Goal(String name, double progress, 
            double target, LocalDateTime deadline) {
        super(name);
        this.progress = progress;
        this.target = target;
        reward = true;
        this.deadline = deadline;
    }
    public Goal(String name, double progress, double target, 
            boolean reward, LocalDateTime deadline) {
        super(name);
        this.progress = progress;
        this.target = target;
        this.reward = reward;
        this.deadline = deadline;
    }
    
    public double getProgress() {
        return progress;
    }
    public void setProgress(double progress) {
        this.progress = progress;
        updateGoal();
    }
    public void updateProgress(double change) {
        progress += change;
        updateGoal();
    }
    
    public double getTarget() {
        return target;
    }
    public void setTarget(double target) {
        this.target = target;
    }
    
    public boolean getReward() {
        return reward;
    }
    public void setReward(boolean reward) {
        this.reward = reward;
    }
    
    public LocalDateTime getDeadline() {
        return deadline;
    }
    public void setDeadline(LocalDateTime deadline) {
        this.deadline = deadline;
    }
    
    /* If reward is true, the User is rewarded for increasing progress.
    If reward is false, the User is rewarded for decreasing progress. */
    public void updateGoal() {
        int counter = reward ? 1 : -1;
        complete = (progress * counter >= target * counter);
    }
}