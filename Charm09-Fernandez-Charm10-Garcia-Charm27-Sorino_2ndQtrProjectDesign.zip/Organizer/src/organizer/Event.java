package organizer;
import java.util.*;
import java.time.*;
/**
 *
 * @author Christian Brandon
 */
public class Event extends Task {
    private LocalDateTime date;
    private String location;
    private ArrayList<String> participants;
    
    public Event(String name, LocalDateTime date) {
        super(name);
        this.date = date;
        this.participants = new ArrayList<>();
    }
    public Event(String name, LocalDateTime date, String location) {
        super(name);
        this.date = date;
        this.location = location;
        this.participants = new ArrayList<>();
    }
    
    public LocalDateTime getDate() {
        return date;
    }
    public void setDate(LocalDateTime date) {
        this.date = date;
    }
    
    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }
    
    public ArrayList<String> getParticipants() {
        return participants;
    }
    
    public void addParticipant(String person) {
        participants.add(person);
    }
    public void removeParticipant(String person) {
        if (participants.contains(person)) {
            participants.remove(person);
        }
    }
}