package organizer;
import java.time.*;
import java.time.format.*;
/**
 *
 * @author Christian Brandon
 */
public class Organizer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        User u1 = new User("Golden Revolver");
        System.out.println(u1.getName());
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM dd, yyyy hh:mm:ss a");
        System.out.println(LocalDateTime.now().format(formatter));
        
        // Scenario 1: School Day
        System.out.println("==\nSCENARIO 1: SCHOOL DAY");
        LocalDateTime d1 = LocalDateTime.of(2024, 1, 22, 0, 0);
        LocalDateTime d2 = LocalDateTime.of(2024, 1, 16, 18, 0);
        Requirement r1 = new Requirement("Literature Review", "Research", d1);
        Requirement r2 = new Requirement("Family Pedigree", "Biology", d2);
        
        u1.addTask(r1);
        u1.addTask(r2);
        
        r1.setComplete(true); // User finishes the literature review
        
        // Display late requirements that haven't been completed
        for (Requirement r : u1.getRequirementList()) {
            if (r.isLate() && !r.isComplete()) {
                System.out.printf("Name: %s\nSubject: %s\n", 
                        r.getName(), r.getSubject());
            }
        }
        
        // Scenario 2: Reunion
        System.out.println("==\nSCENARIO 2: REUNION");
        LocalDateTime d3 = LocalDateTime.of(2024, 6, 30, 12, 30);
        Event e1 = new Event("Family Reunion", d3, "Sorsogon");
        e1.addParticipant("Silver");
        e1.addParticipant("Bronze");
        
        // Display the participants list
        System.out.printf("Name: %s\nLocation: %s\nParticipants: %s\n",
                e1.getName(), e1.getLocation(),e1.getParticipants());
        
        // Scenario 3: Workout Plan
        System.out.println("==\nSCENARIO 3: WORKOUT PLAN");
        
        LocalDateTime d4 = LocalDateTime.of(2024, 1, 30, 0, 0);
        LocalDateTime d5 = LocalDateTime.of(2024, 2, 12, 0, 0);
        Habit h1 = new Habit("Complete exercise plan");
        Goal g1 = new Goal("Push-ups", 10, d4);
        Goal g2 = new Goal("Lose weight", 50.0, 40.0, false, d5);
        
        u1.addTask(h1);
        u1.addTask(g1);
        u1.addTask(g2);
        
        h1.setComplete(true);
        h1.updateStreak(); // Assuming a day has passed
        g1.updateProgress(8);
        g2.updateProgress(-12.5);
        
        // Display the habit streak
        System.out.printf("Name: %s\nStreak: %d\n", 
                h1.getName(), h1.getStreak());
        
        // Display the goals that have been completed
        for (Goal g : u1.getGoalList()) {
            if (g.isComplete()) {
                System.out.printf("Name: %s\nProgress: %.1f\nTarget: %.1f\n", 
                        g.getName(), g.getProgress(), g.getTarget());
            } 
        }
    }
}