package organizer;
import java.util.*;
/**
 *
 * @author Christian Brandon
 */
public class User {
    private String name;
    private ArrayList<Task> taskList;
    private ArrayList<Habit> habitList;
    private ArrayList<Goal> goalList;
    private ArrayList<Event> eventList;
    private ArrayList<Requirement> requirementList;
    
    public User(String name) {
        this.name = name;
        this.taskList = new ArrayList<>();
        this.habitList = new ArrayList<>();
        this.goalList = new ArrayList<>();
        this.eventList = new ArrayList<>();
        this.requirementList = new ArrayList<>();
    }
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public ArrayList<Task> getTaskList() {
        return taskList;
    }
    public ArrayList<Habit> getHabitList() {
        return habitList;
    }
    public ArrayList<Goal> getGoalList() {
        return goalList;
    }
    public ArrayList<Event> getEventList() {
        return eventList;
    }
    public ArrayList<Requirement> getRequirementList() {
        return requirementList;
    }
    
    public void addTask(Task task) {
        taskList.add(task);
        if (task instanceof Habit h) habitList.add(h);
        else if (task instanceof Goal g) goalList.add(g);
        else if (task instanceof Event e) eventList.add(e);
        else if (task instanceof Requirement r) requirementList.add(r);
    }  
    public void deleteTask(Task task) throws TaskNotFoundException {
        if (!taskList.contains(task)) {
            throw new TaskNotFoundException("Task not found!");
        } else { 
            taskList.remove(task);
            if (task instanceof Habit h) habitList.remove(h);
            else if (task instanceof Goal g) goalList.remove(g);
            else if (task instanceof Event e) eventList.remove(e);
            else if (task instanceof Requirement r) requirementList.remove(r);
        }
    }
}