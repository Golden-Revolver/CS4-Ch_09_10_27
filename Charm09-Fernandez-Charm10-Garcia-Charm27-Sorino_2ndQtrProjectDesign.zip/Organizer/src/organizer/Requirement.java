package organizer;
import java.time.*;
/**
 *
 * @author Christian Brandon
 */
public class Requirement extends Task {
    private String subject;
    private LocalDateTime deadline;
    private boolean late;
    
    public Requirement(String name, String subject, LocalDateTime deadline) {
        super(name);
        this.subject = subject;
        this.deadline = deadline;
        late = LocalDateTime.now().isAfter(deadline);
    }
    
    public String getSubject() {
        return subject;
    }
    public void setSubject(String subject) {
        this.subject = subject;
    }
    
    public LocalDateTime getDeadline() {
        return deadline;
    }
    public void setDeadline(LocalDateTime deadline) {
        this.deadline = deadline;
    }
    
    public boolean isLate() {
        return late;
    }
    public void setLate(boolean late) {
        this.late = late;
    }
    public void updateLate() {
        late = LocalDateTime.now().isAfter(deadline);
    }
}